#+eval=FALSE
##probabilite de A et B
 p1<-choose(2,1)/choose(5,1)
 p1
##[1] 0.4
 p2<-choose(3,1)/choose(6,1)
 p2
##[1] 0.5
 p<-p1*p2
 p
##[1] 0.2