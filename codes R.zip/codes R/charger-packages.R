#+eval=FALSE
library("nom du package")