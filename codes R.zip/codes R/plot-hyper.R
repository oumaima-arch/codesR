#+eval=FALSE
plot(0:3,dhyper(0:3,12,8,3),type='h',xlab='X',ylab='P(X=k)',frame=FALSE,xaxt='n',col='red')
axis(1,seq(0,4,length=9))