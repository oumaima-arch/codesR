#+eval=FALSE
install.packages("nom du package") 
