#+eval=FALSE
"Bonjour"
##[1] "Bonjour"
 mode("Bonjour")
##[1] "character"
 typeof("Bonjour")
##[1] "character"
 
  