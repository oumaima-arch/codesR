#+eval=FALSE
 switch(valeur_test, cas1 = {
  instruction1
}, cas2= {
  instruction2
},..., {
  instruction_defaut
})