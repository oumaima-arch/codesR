#+eval=FALSE
curve(dnorm(x,10,0.2),9.2,10.8, ylab ="fX(x)",main="la densit de X")