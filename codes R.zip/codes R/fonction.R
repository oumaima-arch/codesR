#+eval=FALSE
nom_fonction <- function(arguments){ expression
  return(resultat)
}
