#+eval=FALSE
sample(x,size,replace=FALSE,prob=NULL)
