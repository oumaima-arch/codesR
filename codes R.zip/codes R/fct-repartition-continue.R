#+eval=FALSE
 Tailles<-c(150,152,154,156,158,160,162,164,166,168,170,172,174)
 Frequence_cum<-c(0,0,cumsum(frequ),1)
 plot(Tailles,Frequence_cum,type="b",main="",xaxt="n")
 axis(1,c(152,154,156,158,160,162,164,166,168,170,172))
 