#+eval=FALSE
 pie(table(EC),radius=1.0)