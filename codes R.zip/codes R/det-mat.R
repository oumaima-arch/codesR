#+eval=FALSE
 det(A)
##[1] 137