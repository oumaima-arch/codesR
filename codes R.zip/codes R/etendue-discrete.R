#+eval=FALSE
 e<-max(Z)-min(Z)
 e
##[1] 7