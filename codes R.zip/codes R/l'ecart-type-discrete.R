#+eval=FALSE
 sd(Z)
##[1] 1.630826
 sqrt(var(Z))
##[1] 1.630826