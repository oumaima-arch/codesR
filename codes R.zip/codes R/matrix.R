#+eval=FALSE
 X<-matrix(1:9,nrow=3,ncol=3,byrow=TRUE)
 X
## [,1] [,2] [,3]
## [1,]    1    2    3
## [2,]    4    5    6
## [3,]    7    8    9
 Y<-matrix(1:9,nrow=3,ncol=3,byrow=FALSE)
 Y
## [,1] [,2] [,3]
## [1,]    1    4    7
## [2,]    2    5    8
## [3,]    3    6    9
 is.matrix(X)
## [1] TRUE
 is.matrix(Y)
## [1] TRUE