#+eval=FALSE
diag(A)
##[1]  3  1 -7
sum(diag(A))
##[1] -3