#+eval=FALSE
 barplot(ef)
##ou bien
 barplot(ef,ylim=c(0,max(ef)+1))