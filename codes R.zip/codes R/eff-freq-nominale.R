#+eval=FALSE
 EC<-factor(c('marie','divorce','marie','celibataire','celibataire','marie','celibataire','celibataire','celibataire','marie','celibataire','marie','veuf','marie','veuf','divorce','celibataire','celibataire','marie','celibataire','celibataire','veuf','divorce','divorce'))
 EC
## [1] mari�       divorc�     mari�       celibataire celibataire mari�      
## [7] celibataire celibataire celibataire mari�       celibataire mari�      
## [13] veuf        mari�       veuf        divorc�     celibataire celibataire
## [19] mari�       celibataire celibataire veuf        divorc�     divorc�    
## Levels: celibataire divorc� mari� veuf
 ef<-table(EC)
 ef
## EC
## celibataire     divorc�       mari�        veuf 
##          10           4           7           3 
 fr<-ef/sum(ef)
 fr
## EC
## celibataire     divorc�       mari�        veuf 
##   0.4166667   0.1666667   0.2916667   0.1250000 