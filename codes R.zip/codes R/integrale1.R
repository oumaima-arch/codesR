#+eval=FALSE
fct<-function(x){1/((x+1)*sqrt(x))}
 integrate(fct,0,Inf)
##3.141593 with absolute error < 2.7e-05
 integrate(fct,0,Inf)$value
##[1] 3.141593