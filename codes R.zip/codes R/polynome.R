#+eval=FALSE
polyroot(c(-4,0,4))
##[1]  1+0i -1+0i
polyroot(c(1,1,1,1))
##[1]  0+1i -1+0i  0-1i
polyroot(c(-1,0,0,0,1))
##[1]  0+1i -1-0i  0-1i  1+0i