#+eval=FALSE
 var(Z)
##[1] 2.659592