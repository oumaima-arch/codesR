#+eval=FALSE
mat<-matrix(1:12,nrow=4,ncol=3)
mat
##     [,1] [,2] [,3]
##[1,]    1    5    9
##[2,]    2    6   10
##[3,]    3    7   11
##[4,]    4    8   12
mat[,1]      ##la 1�re colonne 
##[1] 1 2 3 4
mat[3,]      ##la 3�me ligne
##[1]  3  7 11
mat[4,2]   ##en combinant la 4�me ligne et la 2�me colonne
##[1] 8