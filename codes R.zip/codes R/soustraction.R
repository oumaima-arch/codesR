#+eval=FALSE 
b-a
##[1] 3

  

  