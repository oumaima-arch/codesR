#+eval=FALSE
integrate(fct,lower=0,upper=1)$value
##[1] 1