#+eval=FALSE
c(1,6,0,4,2)
##[1] 1 6 0 4 2
 is.vector(c(1,6,0,4,2))
##[1] TRUE
 