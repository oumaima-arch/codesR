#+eval=FALSE
Y<-factor(c(rep("bleu",10),rep("vert",50),rep("marron",20),rep("bleu",20),rep("vert",60),rep("marron",40)))
 X<-factor(c(rep("homme",80),rep("femme",120)))
 table(X,Y)
##       Y
##X       bleu marron vert
##  femme   20     40   60
##  homme   10     20   50
 effectif<-table(X,Y)
 frequence<-effectif/sum(effectif)
 frequence
##       Y
##X       bleu marron vert
##  femme 0.10   0.20 0.30
##  homme 0.05   0.10 0.25
 table.contingence<-addmargins(effectif,FUN=sum,quiet=TRUE)
 table.contingence
##       Y
##X       bleu marron vert sum
##  femme   20     40   60 120
##  homme   10     20   50  80
##  sum     30     60  110 200
 table.contingence.freq<-addmargins(frequence,FUN=sum,quiet=TRUE)
 table.contingence.freq
##       Y
##X       bleu marron vert  sum
##  femme 0.10   0.20 0.30 0.60
##  homme 0.05   0.10 0.25 0.40
##  sum   0.15   0.30 0.55 1.00
 prop.table(frequence,1)
##       Y
##X            bleu    marron      vert
##  femme 0.1666667 0.3333333 0.5000000
##  homme 0.1250000 0.2500000 0.6250000
 prop.table(frequence,2)
##       Y
##X            bleu    marron      vert
##  femme 0.6666667 0.6666667 0.5454545
##  homme 0.3333333 0.3333333 0.4545455