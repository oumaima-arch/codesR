#+eval=FALSE
boxplot(Z1,ylab="tailles")
 rug(Z1,side=2)