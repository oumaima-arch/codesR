#+eval=FALSE
while(condition) instruction