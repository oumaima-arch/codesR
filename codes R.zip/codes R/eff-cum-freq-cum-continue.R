#+eval=FALSE
 r$counts/sum(r$counts)
##[1] 0.16 0.14 0.10 0.16 0.08 0.10 0.04 0.08 0.06 0.08
 cumsum(r$counts)
##[1]  8 15 20 28 32 37 39 43 46 50
 cumsum(r$counts)/sum(r$counts)
##[1] 0.16 0.30 0.40 0.56 0.64 0.74 0.78 0.86 0.92 1.00
