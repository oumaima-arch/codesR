#+eval=FALSE
 gl(3,6)
##[1] 1 1 1 1 1 1 2 2 2 2 2 2 3 3 3 3 3 3
##Levels: 1 2 3
 gl(3,6,length=7)
##[1] 1 1 1 1 1 1 2
##Levels: 1 2 3
 gl(3,6,labels=c("un","deux","trois"))
##[1] un    un    un    un    un    un    deux  deux  deux  deux  deux  deux  trois
##[14] trois trois trois trois trois
##Levels: un deux trois