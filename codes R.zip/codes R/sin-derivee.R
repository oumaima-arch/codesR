#+eval=FALSE
D(expression(sin(x)),"x")
##cos(x)