#+eval=FALSE
barplot(eff)