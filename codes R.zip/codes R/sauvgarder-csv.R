#+eval=FALSE
write.table("Book1.csv",sep=";")
"x"
"1";"Book1.csv"