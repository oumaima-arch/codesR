#+eval=FALSE
 1/0
##[1] Inf
 -1/0
##[1] -Inf
 
 