#+eval=FALSE
 boxplot(Z,ylab="nombre de personnes par menage")