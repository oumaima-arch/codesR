#+eval=FALSE
 IQR(Z)
##[1] 2