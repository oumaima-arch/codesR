#+eval=FALSE
 M<-matrix(1:6,nrow=2,ncol=3)
 ncol(M)
##[1] 3
 nrow(M)
##[1] 2
 dim(M)
##[1] 2 3