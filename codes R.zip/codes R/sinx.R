#+eval=FALSE
plot(x,sin(x),type="l",main="La fonction sin(x) et sa drive")
curve(cos(x),-pi,pi,add=T,col="red")
legend("topleft",lty = 1,col=c("black","red"),legend=c("sin(x)","cos(x)"))
