#+eval=FALSE
plot(0:30,dpois(0:30,3),xlab="x",ylab="P(X=x)",type='h',frame=FALSE)