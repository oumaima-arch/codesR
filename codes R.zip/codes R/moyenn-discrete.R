#+eval=FALSE
 mean(Z)
##[1] 3.44