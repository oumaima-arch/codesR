#+eval=FALSE
 vec<-20:60
 vec
##[1] 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45
##[27] 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60
 vec[29]   ##le 29�me �l�ment
##[1] 48
 vec[c(22,31)]  ##le 22�me et le 31�me �l�ment
##[1] 41 50
 vec[22:31]  ##tous les �l�ments entre la 22�me et la 31�me position
##[1] 41 42 43 44 45 46 47 48 49 50 
