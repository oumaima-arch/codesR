#+eval=FALSE
 Dip<-factor(c("Sd","Sd","Sd","Sd","P","P","P","P","P","P","P","P","P","P","P",
                +               "Se","Se","Se","Se","Se","Se","Se","Se","Se","Se","Se","Se","Se","Se",
                +               "Su","Su","Su","Su","Su","Su","Su","Su","Su",
                +               "U","U","U","U","U","U","U","U","U","U","U","U"))
 eff<-table(Dip)
 eff
## Dip
## P Sd Se Su  U 
## 11  4 14  9 12 
 freq<-eff/sum(eff)
 freq
## Dip
## P   Sd   Se   Su    U 
## 0.22 0.08 0.28 0.18 0.24 
 effcum<-cumsum(eff)
 effcum
## P Sd Se Su  U 
## 11 15 29 38 50 
 freqcum<-cumsum(freq)
 freqcum
## P   Sd   Se   Su    U 
## 0.22 0.30 0.58 0.76 1.00 