#+eval=FALSE
Mu<-10
sigma<-0.2
esp<-Mu
esp
##[1] 10
var<-sigma^2
var
##[1] 0.04