#+eval=FALSE
 a<-0
 b<-10
 esp<-(a+b)/2
 esp
##[1] 5
 var<-(b-a)^2/12
 var
##[1] 8.333333