#+eval=fALSE
 v<-c(5,12,17,20,25,30)
 v
##[1]  5 12 17 20 25 30
 sum(v)
##[1] 109
 prod(v)
##[1] 15300000
 mean(v)
##[1] 18.16667
 var(v)
##[1] 80.56667
 sd(v)            
##[1] 8.975894
 sqrt(var(v))     ##l'ecart type=la racine de la variance
##[1] 8.975894
 diff(v)
##[1] 7 5 3 5 5
 min(v)
##[1] 5
 max(v)
##[1] 30
 median(v)
##[1] 18.5