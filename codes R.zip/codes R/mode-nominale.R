#+eval=FALSE
 sort(ef,decreasing=TRUE)
## EC
## celibataire       marie     divorce        veuf 
## 10           7           4           3 