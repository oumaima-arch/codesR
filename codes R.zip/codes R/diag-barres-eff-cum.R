#+eval=FALSE
barplot(effcum)