#+eval=FALSE
 0/0
##[1] NaN
 0*Inf
##[1] NaN
 