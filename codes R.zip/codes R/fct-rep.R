#+eval=FALSE
x<-0:3
fx<-c(0,1/8,4/8,7/8,1)
plot(stepfun(x,fx),main="la fonction de rn",col="red")