#+eval=FALSE
 x<-2
 if(x > 0){print("positive number")}
##[1] "positive number"
 x<- -2
 if(x > 0){
   print("non-negative number")
 }else{
     print("negative number")
   }
##[1] "negative number"
 if(x > 0) print("non-negative number") else print("negative number")
##[1] "negative number"