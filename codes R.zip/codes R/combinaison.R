#+eval=FALSE
choose(5,3)
##[1] 10
(factorial(5))/(factorial(3)*factorial(5-3))
##[1] 10
