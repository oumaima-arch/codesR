#+eval=FALSE
curve(punif(x,0,10),-5,15,ylab='F(X)',main='la fonction de rpartition',frame=F)