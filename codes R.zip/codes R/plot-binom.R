#+eval=FALSE
P<-dbinom(0:4,4,1/6)
plot(P,xlab="",type='h',frame=FALSE)