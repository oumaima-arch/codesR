#+eval=FALSE
 carre<-function(x) return(x^2)
 carre(4)
##[1] 16
 carre(5)
##[1] 25