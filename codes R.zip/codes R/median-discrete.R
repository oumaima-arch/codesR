#+eval=FALSE
 median(Z)
##[1] 3