#+eval=FALSE
boxplot(z1,main="boite a moustache")