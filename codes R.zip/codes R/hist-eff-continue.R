#+eval=FALSE
hist(Z1,breaks=c(152,154,156,158,160,162,164,166,168,170,172),main="Histogramme des effectifs",xlab="Tailles",ylab="effectif")