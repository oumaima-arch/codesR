#+eval=FALSE
hist(z1,breaks=c(5.11,5.31,5.51,5.71,5.91,6.11),freq=FALSE,main="Histogramme des frequences",xlab="",ylab="",col='cyan')