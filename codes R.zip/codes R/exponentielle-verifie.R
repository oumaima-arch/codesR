#+eval=FALSE
 1-exp(-lambda*10000)
##[1] 0.3934693
 exp(-lambda*15000)
##[1] 0.4723666
 1-exp(-lambda*15000)-1+exp(-lambda*10000)
##[1] 0.1341641
 