#+eval=FALSE
for (variable in vector) instruction


