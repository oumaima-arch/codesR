#+eval=FALSE 
 a*b
##[1] 10

  

  

  