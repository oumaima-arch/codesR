#+eval=FALSE
 a<-matrix(c(1,-1,2,4),ncol=2,byrow=T)
 a
##[,1] [,2]
##[1,]    1   -1
##[2,]    2    4
eigen(a)
##eigen() decomposition
##$values
##[1] 3 2

##$vectors
##[,1]       [,2]
##[1,]  0.4472136 -0.7071068
##[2,] -0.8944272  0.7071068
