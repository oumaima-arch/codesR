#+eval=FALSE
boxplot(z1,main="boite a moustache")
rug(z1,side=2)