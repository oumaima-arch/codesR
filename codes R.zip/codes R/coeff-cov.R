#+eval=FALSE
 cov(x,y)
##[1] -2.930323
 r<-cov(x,y)/(sd(x)*sd(y))
  r
##[1] -0.2920606
 cor(x,y)
##[1] -0.2920606