#+eval=FALSE
 T
##[1] TRUE
 F
##[1] FALSE
 (T<-4)
##[1] 4