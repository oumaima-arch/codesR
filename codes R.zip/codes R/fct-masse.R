#+eval=FALSE
p<-c(1/8,3/8,3/8,1/8)
x<-0:3
plot(x,p,type='h',main="la fonction de masse",col="red")