if (condition){ 
  une ou plusieurs commandes � faire si la condition est vraie
}
