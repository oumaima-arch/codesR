#+eval=FALSE 
a <- 2
mode(a)
## [1] "numeric"

  

  

  

  

  

  