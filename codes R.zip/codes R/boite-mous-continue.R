#+eval=FALSE
boxplot(Z1,ylab="tailles")
