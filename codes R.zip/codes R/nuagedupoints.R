#+eval=FALSE
 poids
##[1]  60  61  74  67  68  69  70  70  72  73  75  76  78  80  85  90  96  96  98 101
 taille
##[1] 155 162 157 170 164 162 169 170 178 173 180 175 173 175 179 175 180 185 189 187
plot(taille,poids)
d<-lm(poids~taille)
 d

##Call:
##lm(formula = poids ~ taille)

##Coefficients:
##  (Intercept)       taille  
##     -109.979        1.087 
abline(d,col="red")