#+eval=FALSE
D(expression(exp(x)/(x-1)),"x")
##exp(x)/(x - 1) - exp(x)/(x - 1)^2