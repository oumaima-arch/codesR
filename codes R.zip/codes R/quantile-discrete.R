#+eval=FALSE
 quantile(Z)
##0%  25%  50%  75% 100% 
##1    2    3    4    8 