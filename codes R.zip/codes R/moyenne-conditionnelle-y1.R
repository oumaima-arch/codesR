#+eval=FALSE
 yj<-c(2,4,6,8)
 n1j<-c(0,4,3,1)
 y1<-1/8*sum(n1j*yj)
 y1
##[1] 5.25