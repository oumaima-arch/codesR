#+eval=FALSE
 a<-c(TRUE,TRUE,FALSE,FALSE)
 b<-c(TRUE,FALSE,TRUE,FALSE)
 a
##[1]  TRUE  TRUE FALSE FALSE
 b
##[1]  TRUE FALSE  TRUE FALSE
 !a  ##la n�gation
##[1] FALSE FALSE  TRUE  TRUE
 !b  ##la n�gation
##[1] FALSE  TRUE FALSE  TRUE
 a&b  ##l'intersection logique 
##[1]  TRUE FALSE FALSE FALSE
 a|b  ##l'union logique
##[1]  TRUE  TRUE  TRUE FALSE