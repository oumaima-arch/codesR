#+eval=FALSE
 a<-c(2,5,7,3,8)
 b<-c(1,4,6,3,9)
 k<-10
 a+b  ##addition
##[1]  3  9 13  6 17
 a-b  ##soustraction
##[1]  1  1  1  0 -1
 a*b  ##multiplication
##[1]  2 20 42  9 72
 k*a  ##multiplication par un scalaire 
##[1] 20 50 70 30 80
 a/b  ##division
##[1] 2.0000000 1.2500000 1.1666667 1.0000000 0.8888889
 a%/%b  ##quotion
##[1] 2 1 1 1 0
 a%%b ##le reste
 ##[1] 0 1 1 0 8
 a^b  ##la puissance 
##[1]         2       625    117649        27 134217728