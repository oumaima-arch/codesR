#+eval=FALSE
 V<-c(x1=1,x2=6,x3=0,x4=4,x5=2)
 V
## x1 x2 x3 x4 x5 
## 1  6  0  4  2 
 U<-c(1,6,0,4,2)
 names(U)<-c('x1','x2','x3','x4','x5')
 U
## x1 x2 x3 x4 x5 
## 1  6  0  4  2 