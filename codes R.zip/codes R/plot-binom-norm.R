#+eval=FALSE
 plot(0:60,dbinom(0:60,180,1/6),type='h',xlab='X',ylab='',main="Densite associees au lois B(180,1/6) et N(30,5)")
 curve(dnorm(x,30,5),0,60,col='red',add=T)