#+eval=FALSE
L<-list(chaine.de.caracteres="Bonjour",nombre.complexe=2+7i,logique=TRUE,vecteur=c(1.5,2.5,3.5),matrice=matrix(1:9,nrow=3))
 attributes(L)
## $names
## [1] "chaine.de.caracteres" "nombre.complexe"      "logique"             
## [4] "vecteur"              "matrice"             

