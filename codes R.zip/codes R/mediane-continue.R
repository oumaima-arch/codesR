#+eval=FALSE
 integrate(fct,0,1/4)
##0.5 with absolute error < 1.4e-15
 integrate(fct,0,1/4)$value
##[1] 0.5