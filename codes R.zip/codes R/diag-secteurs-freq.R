#+eval=FALSE
pie(freq,radius=1.0)