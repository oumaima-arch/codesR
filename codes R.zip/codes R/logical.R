#+eval=FALSE
 4>2
##[1] TRUE
 4==2
##[1] FALSE
 mode(4>2)
##[1] "logical"
 typeof(4==2)
##[1] "logical"
 