#+eval=FALSE
 mean(x)
##[1] 18.28
 mean(y)
##[1] 4.496