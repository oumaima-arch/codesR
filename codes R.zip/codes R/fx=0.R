#+eval=FALSE
f1<-function(x) 2*x-2
uniroot(f1,c(0,2))$root
##[1] 1
f2<-function(x) x-2^(-x)
uniroot(f2,c(0,1))$root
##[1] 0.6411922
f3<-function(x) exp(x)+2^(-x)+2*cos(x)-6
uniroot(f3,c(1,2))$root
##[1] 1.829373
f4<-function(x) exp(x)-4*x
uniroot(f4,c(0,1/2))$root
##[1] 0.3574035