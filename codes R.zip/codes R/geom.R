#+eval=FALSE
dgeom(x,1/2)
##[1] 0.03125
(1-p)^(5-1)*p
##[1] 0.03125
esp<-1/p
esp
##[1] 2
var<-(1-p)/p^2
var
##[1] 2