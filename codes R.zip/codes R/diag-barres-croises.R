#+eval=FALSE
barplot(table(X,Y),main="Graphique des couples (X,Y)",legend.text=TRUE)