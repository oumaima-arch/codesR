#+eval=FALSE
 lambda<-0.00005
 esp<-1/lambda
 esp
##[1] 20000