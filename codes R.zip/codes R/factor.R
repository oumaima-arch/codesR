#+eval=FALSE
 factor(c("A","B","A","A","B","B"))
## [1] A B A A B B
## Levels: A B
 