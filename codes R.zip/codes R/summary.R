#+eval=FALSE
 summary(v)
## Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
## 5.00   13.25   18.50   18.17   23.75   30.00 
 summary(m)
##       V1            V2     
## Min.   :1.0   Min.   :4.0  
## 1st Qu.:1.5   1st Qu.:4.5  
## Median :2.0   Median :5.0  
## Mean   :2.0   Mean   :5.0  
## 3rd Qu.:2.5   3rd Qu.:5.5  
## Max.   :3.0   Max.   :6.0  
 summary(d)
##      Age            Taille         Genre          
## Min.   :20.00   Min.   :160.0   Length:4          
## 1st Qu.:20.75   1st Qu.:163.8   Class :character  
## Median :21.50   Median :167.5   Mode  :character  
## Mean   :21.50   Mean   :167.5                     
## 3rd Qu.:22.25   3rd Qu.:171.2                     
## Max.   :23.00   Max.   :175.0 