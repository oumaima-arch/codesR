#+eval=FALSE
L<-c(4.91,5.11,5.31,5.51,5.71,5.91,6.11,6.31)
freq_cum<-c(0,0,cumsum(frequ),1)
plot(L,freq_cum,type="b",main="Fonction de rpartition d'une distribution groupe",xaxt="n")
axis(1,c(5.11,5.31,5.51,5.71,5.91,6.11))