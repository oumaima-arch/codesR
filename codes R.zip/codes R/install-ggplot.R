#+eval=FALSE
install.packages("ggplot2")