#+eval=FALSE
mean(z1)
##[1] 5.602
median(z1)
##[1] 5.575