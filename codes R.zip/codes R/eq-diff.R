#+eval=FALSE
library('deSolve')
fct<-function(t,y,a){sol=a*y; return(list(sol))}
t<-seq(0,1/2,0.1)
y0<-3
ode(y=y0,times=t,func=fct,parms=2)
##  time        1
##1  0.0 3.000000
##2  0.1 3.664210
##3  0.2 4.475477
##4  0.3 5.466360
##5  0.4 6.676631
##6  0.5 8.154855