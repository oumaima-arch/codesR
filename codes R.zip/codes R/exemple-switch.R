 switch(2,"red","green","blue")
##[1] "green"
 switch(1,"red","green","blue")
##[1] "red"