#+eval=FALSE
 x<-c("FF","FP","PF","PP")
 sample(x,2,prob=c(0.5,0.5,0,0))
##[1] "FF" "FP"
 sample(x,2,prob=c(0,0.5,0,0.5))
##[1] "PP" "FP"