#+eval=FALSE
 Cvx<-sd(x)/mean(x)
 Cvx
##[1] 0.3475551
 Cvy<-sd(y)/mean(y)
 Cvy
##[1] 0.35125