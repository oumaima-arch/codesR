#+eval=FALSE
 D(expression(x^n),"x")
##x^(n - 1) * n
 D(expression(exp(a*x)),"x")
##exp(a * x) * a