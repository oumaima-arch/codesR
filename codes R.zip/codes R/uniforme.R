#+eval=FALSE
 punif(3,0,10)
##[1] 0.3
 1-punif(6,0,10)
##[1] 0.4
 punif(8,0,10)-punif(3,0,10)
##[1] 0.5