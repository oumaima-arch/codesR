#+eval=FALSE
sort(table(Z),decreasing=TRUE)
##Z
##3  4  2  5  1  6  8 
##15 10  9  6  5  3  2 
