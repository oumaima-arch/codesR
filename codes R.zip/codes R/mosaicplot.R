#+eval=FALSE
mosaicplot(X~Y,col=c("blue","brown","green"),main="Mosaicplot de X en fonction de Y")