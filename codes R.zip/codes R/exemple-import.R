#+eval=FALSE
d<-read.table("Book1.csv",sep=";",dec=",",header=TRUE)
d
##   �..nom prenom age
##1 ahrouch   said  35
##2  lazaar  salma  21
##3    said   hind  20
##4  halimi  fouad  30
head(d)
##   �..nom prenom age
##1 ahrouch   said  35
##2  lazaar  salma  21
##3    said   hind  20
##4  halimi  fouad  30
d1<-read.table(file.choose(),sep=";",dec=",",header=TRUE)
d1
##   �..nom prenom age
##1 ahrouch   said  35
##2  lazaar  salma  21
##3    said   hind  20
##4  halimi  fouad  30