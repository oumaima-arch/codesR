 v<-NULL
 for(i in 1:4){
   v[i]<-i
 }
 v
##[1] 1 2 3 4