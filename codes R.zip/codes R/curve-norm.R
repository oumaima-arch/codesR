#+eval=FALSE
curve(pnorm(x,10,0.2),9.2,10.5, ylab = "Fonction de rpartition")