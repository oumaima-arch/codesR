#+eval=FALSE
##1st form
if (condition) instruction 
##2nd form
if (condition) instruction else instruction
