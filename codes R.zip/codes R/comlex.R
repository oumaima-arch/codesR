#+eval=FALSE
 1+2i
##[1] 1+2i
 mode(1+2i)
##[1] "complex"
 Re(1+2i)
##[1] 1
 Im(1+2i)
##[1] 2
 Mod(1+2i)
##[1] 2.236068
 Arg(1+2i)
##[1] 1.107149
