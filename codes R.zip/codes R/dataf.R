#+eval=FALSE
 d<-data.frame(Age=c(20,21,22,23),Taille=c(160,165,170,175),Genre=c('F','F','M','M'))
 d
##   Age Taille Genre
## 1  20    160     F
## 2  21    165     F
## 3  22    170     M
## 4  23    175     M
 d[4,2]
##[1] 175
 d$Age #le vecteur Age
##[1] 20 21 22 23 
 d[d$Age>21,] #toutes les colonnes avec l'age>21
##  Age Taille Genre
##3  22    170     M
##4  23    175     M