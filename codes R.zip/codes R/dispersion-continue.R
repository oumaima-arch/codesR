#+eval=FALSE
 e<-max(Z1)-min(Z1)
 e
##[1] 19
 IQR(Z1)
##[1] 8.75
 var(Z1)
##[1] 34.05265
 sd(Z1)
##[1] 5.835465