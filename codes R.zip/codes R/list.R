#+eval=FALSE
 L<-list("Bonjour",2+7i,TRUE,c(1.5,2.5,3.5),matrix(1:9,nrow=3))
 L
## [[1]]
## [1] "Bonjour"

## [[2]]
## [1] 2+7i

## [[3]]
## [1] TRUE

## [[4]]
## [1] 1.5 2.5 3.5

## [[5]]
##      [,1] [,2] [,3]
## [1,]    1    4    7
## [2,]    2    5    8
## [3,]    3    6    9

 list(chaine.de.caracteres="Bonjour",nombre.complexe=2+7i,logique=TRUE,vecteur=c(1.5,2.5,3.5),matrice=matrix(1:9,nrow=3))
## $chaine.de.caracteres
## [1] "Bonjour"

## $nombre.complexe
## [1] 2+7i

## $logique
## [1] TRUE

## $vecteur
## [1] 1.5 2.5 3.5

## $matrice
##      [,1] [,2] [,3]
## [1,]    1    4    7
## [2,]    2    5    8
## [3,]    3    6    9