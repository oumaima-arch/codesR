#+eval=FALSE
plot(ecdf(Z),main="Fonction de r�partition de la variable Z",frame=0)