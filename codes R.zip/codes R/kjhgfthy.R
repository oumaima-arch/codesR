#+eval=FALSE
 ef<-table(EC)
 ef
## EC
## celibataire     divorc       mari        veuf 
##          10           4           7           3 
 fr<-ef/sum(ef)
 fr
## EC
## celibataire     divorc       mari        veuf 
##   0.4166667   0.1666667   0.2916667   0.1250000 