#+eval=FALSE
 x<-1.25
 is.numeric(x)
##[1] TRUE
 is.character(x)
##[1] FALSE
y<-as.character(x)
 y
##[1] "1.25"
 mode(y)
##[1] "character"
 is.character(y)
##[1] TRUE
 