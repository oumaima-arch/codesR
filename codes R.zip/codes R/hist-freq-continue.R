#+eval=FALSE
 hist(Z1,breaks=c(152,154,156,158,160,162,164,166,168,170,172),freq=FALSE,
      main="Histogramme des fr�quences",xlab="Tailles",ylab="fr�quence")