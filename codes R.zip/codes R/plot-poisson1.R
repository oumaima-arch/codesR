#+eval=FALSE
plot(0:16,dpois(0:16,3),type='h',xlab="X",ylab="P(X=k)",frame=FALSE)