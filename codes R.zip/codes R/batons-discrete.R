#+eval=FALSE
plot(table(Z),type='h',main="diagramme en batons",xlab="",ylab="effectif",col="green")
##ou bien 
f<-c(5,9,15,10,6,3,2)
z<-c(1,2,3,4,5,6,8)
plot(z,f,type='h',main="diagramme en batons",xlab="",ylab="effectif",col="green")