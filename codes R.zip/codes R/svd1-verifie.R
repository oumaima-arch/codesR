#+eval=FALSE
u%*%d%*%t(Conj(v))
##     [,1] [,2]
##[1,] 1+0i 0-1i
##[2,] 0+1i 3+0i