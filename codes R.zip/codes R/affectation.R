#+eval=FALSE 
2*
  + 6
##[1] 12
 
