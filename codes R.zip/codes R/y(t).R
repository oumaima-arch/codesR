#+eval=FALSE
plot(y,type='b',col='red',xlab="t",main="La solusion de l'quation diffrentielle y(t)=2y(t)")