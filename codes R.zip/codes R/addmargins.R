#+eval=FALSE
addmargins(table(x,y),FUN=sum,quiet=TRUE)
##     y
##x       2   4   6   8 sum
##  5     0   4   3   1   8
##  10    1   4   6   1  12
##  15    4  16  13   2  35
##  20    4  27   6   3  40
##  25    5  10   4   1  20
##  30    5   3   2   0  10
##  sum  19  64  34   8 125