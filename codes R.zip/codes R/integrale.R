#+eval=FALSE
fct<-function(x){1/(2*sqrt(x))}
integrate(fct,lower=0,upper=1)
## 1 with absolute error < 2.9e-15
