#+eval=FALSE
f2<-function(y){2*y}
i<-integrate(f2,lower=0,upper=1)$value
 i
##[1] 1
f1<-function(x){i*sin(x)}
integrate(f1,0,pi)$value
##[1] 2