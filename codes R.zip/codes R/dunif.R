#+eval=FALSE
curve(dunif(x,0,10),-5,15,col='red',frame=F,ylab="f(X)",main="densit de x")