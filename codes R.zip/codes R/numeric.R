#+eval=FALSE
 10
##[1] 10
 mode(10)
##[1] "numeric"
 typeof(10.5)
##[1] "double"
 