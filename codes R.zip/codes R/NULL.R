#+eval=FALSE 
x<-NULL
 mode(x)
##[1] "NULL"