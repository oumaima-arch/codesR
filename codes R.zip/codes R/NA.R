#+eval=FALSE
 x<-NA
 mode(x)
##[1] "logical"
 