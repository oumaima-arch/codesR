#+eval=FALSE
D<-data.frame(Age=c(20,21,22,23),Taille=c(160,165,170,175),Genre=c('F','F','M','M'))
 D
##    Age Taille Genre
##  1  20    160     F
##  2  21    165     F
##  3  22    170     M
##  4  23    175     M
 D<-data.frame(Age=c(20,21,22,23),Taille=c(160,165,170,175),Genre=c('F','F','M','M'),row.names=c('Salma','Malak','Ali','Adil'))
 D
##        Age Taille Genre
##  Salma  20    160     F
##  Malak  21    165     F
##  Ali    22    170     M
##  Adil   23    175     M
 is.data.frame(D)
## [1] TRUE