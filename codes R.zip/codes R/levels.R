#+eval=FALSE
 f<-factor(c("A","B","A","A","B","B"))
 levels(f)
##[1] "A" "B"